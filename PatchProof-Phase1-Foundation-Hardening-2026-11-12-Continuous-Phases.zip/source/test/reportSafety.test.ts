import assert from 'node:assert/strict';
import { generateHtmlReport, generateMarkdownReport } from '../src/utils/securityUtils';
import { ScanResult } from '../src/types/security';

const payload = '</div><script>globalThis.patchproofInjected = true</script>';
const scan = {
  id: 'synthetic-report-1',
  projectName: payload,
  fileName: payload,
  language: 'typescript',
  timestamp: '2026-11-12T00:00:00.000Z',
  modelUsed: 'Context-Aware Static Rules (Local)',
  executionTimeMs: 1,
  originalCode: '',
  summary: payload,
  recommendations: [payload],
  metrics: {
    score: payload as unknown as number,
    grade: 'A+',
    criticalCount: payload as unknown as number,
    highCount: 0,
    mediumCount: 0,
    lowCount: 0,
    infoCount: 0,
    totalFindings: payload as unknown as number,
    confirmedCount: 0,
    likelyCount: 1,
    needsReviewCount: 0,
    falsePositiveCount: 0,
    aiHypothesesCount: 0,
    deterministicCount: 1,
    linesAnalyzed: payload as unknown as number
  },
  findings: [{
    id: 'synthetic-finding-1',
    title: payload,
    filePath: payload,
    cwe: 'CWE-78',
    owaspCategory: 'A03:2021-Injection',
    severity: 'HIGH',
    confidence: 'HIGH',
    verificationStatus: 'LIKELY',
    verificationType: 'STATIC_RULE_MATCH',
    startLine: payload as unknown as number,
    endLine: payload as unknown as number,
    snippet: '<script>alert(1)</script>',
    explanation: payload,
    attackScenario: 'Synthetic test only',
    remediation: 'Use a safe API',
    suggestedPatch: 'const safe = true;',
    status: 'OPEN'
  }]
} as unknown as ScanResult;

const html = generateHtmlReport(scan);
assert.equal(html.includes('<script>'), false, 'HTML report must escape untrusted report strings');
assert.equal(html.includes('</div><script>'), false, 'tampered numeric fields must not escape into HTML');
assert.match(html, /NOT RUN \(not executed\)/, 'missing fix validation must be reported as not run');
assert.equal(html.includes('Confidence: 75%'), false, 'report must not invent a default validation confidence');
assert.match(html, /<div class="score-val">0 /, 'invalid score values should fall back to a safe numeric value');

const markdown = generateMarkdownReport(scan);
assert.match(markdown, /Local analysis \(no remote AI transmission recorded\)/);
assert.match(markdown, /\*\*Method:\*\* STATIC_RULE_MATCH/);
assert.equal(markdown.includes('100% In-Memory Local'), false, 'local browser persistence must not be described as in-memory only');

console.log('Report safety: 8 assertions passed.');
