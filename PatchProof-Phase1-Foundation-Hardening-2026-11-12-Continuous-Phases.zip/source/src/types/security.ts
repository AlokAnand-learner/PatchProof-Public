export type Severity = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'INFO';

export type Confidence = 'HIGH' | 'MEDIUM' | 'LOW';

export type VerificationType = 
  | 'AI_HYPOTHESIS'        // Identified via semantic reasoning, needs verification
  | 'STATIC_RULE_MATCH'    // Deterministic static signature match
  | 'TAINT_FLOW_ANALYSIS'; // Inferred data flow from untrusted source to sink

export type VerificationStatus = 
  | 'CONFIRMED'            // Sufficient context & evidence supports vulnerability
  | 'LIKELY'               // Strong indicators exist, verification incomplete
  | 'NEEDS_REVIEW'         // Insufficient context to make a reliable determination
  | 'FALSE_POSITIVE'       // Available evidence indicates detection does not represent a vulnerability
  | 'NOT_REPRODUCIBLE';    // Could not be statically reproduced in available context

export type FindingStatus = 'OPEN' | 'REVIEWED' | 'FIXED' | 'FALSE_POSITIVE' | 'IGNORED';

export type UserFindingResolution = 'ACTIVE' | 'FALSE_POSITIVE' | 'ACCEPTED_RISK' | 'FIXED';

export interface VulnerabilityFinding {
  id: string;
  title: string;
  filePath?: string;        // Relative file path e.g. "src/auth/login.py"
  cwe: string;              // e.g. "CWE-89: SQL Injection"
  owaspCategory: string;    // e.g. "A03:2021-Injection"
  severity: Severity;
  confidence: Confidence;
  verificationStatus: VerificationStatus; // Confirmed | Likely | Needs Review | False Positive | Not Reproducible
  verificationType: VerificationType;     // Legacy compatibility
  verificationMethod?: string;            // 'TAINT_FLOW_ANALYSIS' | 'STATIC_AST_CHECK' | 'CONTEXTUAL_HEURISTIC' | 'AI_HYPOTHESIS'
  startLine: number;
  endLine: number;
  snippet: string;          // The vulnerable code snippet
  surroundingContext?: string; // 2-3 lines before and after with line numbers
  evidence?: string;        // Specific evidence string
  explanation: string;      // Clear technical explanation
  attackScenario: string;   // Potential impact / attack scenario
  exploitConditions?: string; // Conditions under which the issue could become exploitable
  classificationReason?: string; // Why the issue was classified this way
  reasoning?: string;       // Detailed reasoning
  remainingUncertainty?: string; // Explains what cannot be proven without runtime execution
  remediation: string;      // Guidance on how to fix it securely
  suggestedPatch: string;   // Recommended code change
  patchVerificationStatus?: 'VERIFIED_STATIC' | 'UNVERIFIED_REVIEW_REQUIRED';
  fixValidation?: FixValidationResult; // Intelligent Fix Validation Engine outcome
  status: FindingStatus;
  userResolution?: UserFindingResolution;
  notes?: string;
  dedupKey?: string;
  analysisEngine?: string;  // e.g. "Context-Aware Static Rules (Local)" or "Google Gemini 3.8 Flash (Cloud)"
}

export type FixValidationStatus = 
  | 'VALIDATED'            // Passed all syntax, scope, resolution, and security checks
  | 'PARTIALLY_VALIDATED'  // Passed core security/syntax checks, but has non-blocking notes or missing imports
  | 'NEEDS_REVIEW'         // Requires human developer judgment due to environmental or architectural dependencies
  | 'INVALID';             // Failed validation (syntax error, failed to resolve flaw, or introduced regression)

export interface FixCheckResult {
  passed: boolean;
  status: 'PASS' | 'WARN' | 'FAIL';
  name: string;
  message: string;
  details?: string[];
}

export interface FixValidationResult {
  status: FixValidationStatus;
  overallScore: number;     // 0 to 100 confidence score for the fix
  vulnerabilityResolved: boolean;
  securityImprovement: string;
  potentialCompatibilityIssues: string[];
  syntaxCheck: FixCheckResult;
  scopeAndImportsCheck: FixCheckResult;
  securityRegressionCheck: FixCheckResult;
  completenessCheck: FixCheckResult;
  missingImports: string[];
  undefinedVariables: string[];
  introducedVulnerabilities: string[];
  insecureFallbacks: string[];
  timestamp: string;
  executionMode: 'STATIC_ISOLATED_AST_ANALYSIS';
  validationChecksRun?: string[];
  limitations?: string[];
  fullFileValidationPassed?: boolean;
}

export interface FixValidationTestCase {
  id: string;
  title: string;
  category: string;
  description: string;
  fileName: string;
  language: string;
  vulnerabilityCwe: string;
  vulnerabilityTitle: string;
  originalSnippet: string;
  proposedPatch: string;
  surroundingContext: string;
  expectedStatus: FixValidationStatus;
  expectedCheckFailures?: string[];
  notes: string;
}

export interface SecurityMetrics {
  score: number;             // 0 to 100 (100 = spotless)
  grade: 'A+' | 'A' | 'B' | 'C' | 'D' | 'F';
  criticalCount: number;
  highCount: number;
  mediumCount: number;
  lowCount: number;
  infoCount: number;
  totalFindings: number;
  confirmedCount: number;
  likelyCount: number;
  needsReviewCount: number;
  falsePositiveCount: number;
  aiHypothesesCount: number;
  deterministicCount: number;
  linesAnalyzed: number;
}

export interface ProjectFileRecord {
  filePath: string;
  language: string;
  content: string;
  patchedContent?: string;
  lines: number;
  size: number;
  findingsCount?: number;
}

export interface ScanResult {
  id: string;
  projectName: string;
  fileName: string;
  language: string;
  timestamp: string;
  modelUsed: string;
  executionTimeMs: number;
  originalCode: string;
  patchedFullCode?: string;
  metrics: SecurityMetrics;
  findings: VulnerabilityFinding[];
  summary: string;
  recommendations: string[];
  isMultiFile?: boolean;
  files?: ProjectFileRecord[];
  transmissionMode?: 'LOCAL_ONLY' | 'CLOUD_AI_TRANSMITTED';
  cloudDisclosed?: boolean;
}

export interface StagedFile {
  id: string;
  name: string;
  relativePath: string;
  size: number;
  language: string;
  content: string;
  lines: number;
}

export interface UploadLimits {
  maxSingleFileSize: number;    // default 2MB
  maxArchiveSize: number;       // default 25MB
  maxTotalExtractedSize: number;// default 20MB
  maxFileCount: number;         // default 60 files
  maxArchiveEntries: number;    // default 5000 ZIP entries, including skipped entries
}

export interface SampleCode {
  id: string;
  title: string;
  language: string;
  fileName: string;
  category: string;
  description: string;
  code: string;
  expectedVulnerabilities: string[];
}

export interface HistoryItem {
  id: string;
  projectName: string;
  fileName: string;
  language: string;
  timestamp: string;
  score: number;
  grade: 'A+' | 'A' | 'B' | 'C' | 'D' | 'F';
  totalFindings: number;
  criticalCount: number;
  highCount: number;
  scanResult: ScanResult;
}

export interface EvaluationTestCase {
  id: string;
  title: string;
  category: string;
  description: string;
  code: string;
  fileName: string;
  language: string;
  expectedOutcome: 'VULNERABILITY' | 'SECURE' | 'FALSE_POSITIVE_SUPPRESSED' | 'NEEDS_REVIEW';
  expectedClassification: VerificationStatus;
  expectedCwe?: string;
  rationale: string;
}

export interface EvaluationMetrics {
  totalTestCases: number;
  /** Cases eligible for binary precision/recall scoring; review-only cases are excluded. */
  evaluatedCases: number;
  /** Cases requiring human/context review and therefore excluded from binary scoring. */
  excludedCases: number;
  truePositives: number;
  falsePositives: number;
  trueNegatives: number;
  falseNegatives: number;
  precision: number;
  recall: number;
  f1Score: number;
  accuracy: number;
  timestamp: string;
  results: Array<{
    id: string;
    title: string;
    passed: boolean;
    actualOutcome: string;
    actualClassification: string;
    includedInMetrics: boolean;
    reason: string;
  }>;
}

export type ProviderType = 'gemini' | 'gemma' | 'openai' | 'anthropic' | 'ollama' | 'custom';

export interface ProviderConfig {
  id: ProviderType;
  name: string;
  description: string;
  models: string[];
  selectedModel: string;
  apiKey?: string;        // Server masks this as e.g. "sk-...ab12"
  hasKeyStored?: boolean;
  endpoint?: string;
  isConfigured: boolean;
  isActive: boolean;
  requiresKey: boolean;
  supportsLocal: boolean;
}

export interface OllamaModelInfo {
  name: string;
  model: string;
  size: number;
  digest?: string;
  modified_at?: string;
  isGemma: boolean;
}

export interface SystemStatus {
  status: string;
  offlineMode: boolean;
  cloudConsentGranted: boolean;
  deploymentBoundary: string;
  activeProvider: ProviderType;
  activeModel: string;
  activeProviderEndpoint?: string | null;
  hasApiKey: boolean;
  engine: string;
  serviceName: string;
  ollama: {
    available: boolean;
    endpoint: string;
    installedModels: string[];
    gemmaModels: string[];
    error?: string;
  };
  activeProviderStatus?: 'connected' | 'error' | 'disconnected' | 'testing';
  lastConnectionTest?: {
    success: boolean;
    latencyMs: number;
    message: string;
    timestamp: string;
    provider?: ProviderType;
    model?: string;
  };
}


